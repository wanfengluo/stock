package com.fx.daolmpl;

import com.fx.dao.UserDao;
import com.fx.db.DBconnection;
import com.fx.vo.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDaolmpl implements UserDao {
    public Connection conn;
    public PreparedStatement ps;
    public ResultSet rs;

    @Override
    public boolean login(String name, String password) throws SQLException, ClassNotFoundException {
        boolean flag = false;
        DBconnection db = new DBconnection();
        conn = db.getConn();
        String sql = "select * from user where name = ? and password = ?";
        ps = conn.prepareStatement(sql);
        ps.setString(1, name);
        ps.setString(2, password);

        rs = ps.executeQuery();
        if (rs.next()) {
            flag = true;
        }
        return flag;
    }

    public ArrayList<User> selectAll() {
        ArrayList<User> list = new ArrayList<User>();

        DBconnection db = new DBconnection();
        conn = db.getConn();

        String sql = "select * from user";
        try {
            ps = conn.prepareStatement(sql);

            rs = ps.executeQuery();

            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setAge(rs.getInt("age"));
                u.setSex(rs.getString("sex"));
                u.setPassword(rs.getString("password"));
                u.setSalary((rs.getInt("salary")));

                list.add(u);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return list;
    }

    public boolean add(User u) throws SQLException, ClassNotFoundException {
        DBconnection db = new DBconnection();
        conn = db.getConn();

        String sql = "insert into user values(id,?,?,?,?,?)";
        try {
            ps = conn.prepareStatement(sql);

            ps.setString(1, u.getName());
            ps.setString(2, u.getPassword());
            ps.setInt(3, u.getAge());
            ps.setString(4, u.getSex());
            ps.setInt(5, u.getsalary());

            int flag = ps.executeUpdate();
            if (flag > 0) {
                return true;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }


    @Override
    public boolean delete(int id) throws SQLException, ClassNotFoundException {
        DBconnection db = new DBconnection();
        conn = db.getConn();
        String sql="delete from user where id = ?";
        try{
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            int flag = ps.executeUpdate();
            if (flag > 0){
                return true;
            }
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
        return false;
    }



    @Override
    public User selectById(int id) {
        DBconnection db = null;
        db = new DBconnection();
        conn = db.getConn();
        User u=new User();

        String sql="select * from user where id= ?";
        try {
            ps= conn.prepareStatement(sql);
            ps.setInt(1,id);
            rs=ps.executeQuery();


            while (rs.next()){
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setAge(rs.getInt("age"));
                u.setSex(rs.getString("sex"));
                u.setPassword(rs.getString("password"));
                u.setSalary((rs.getInt("salary")));
            }
            } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return u;
    }

    @Override
    public boolean update(User u) throws SQLException, ClassNotFoundException {
        DBconnection db = new DBconnection();
        conn = db.getConn();

        String sql="update user set name=?,password=?,age=?,sex=?,salary=? where id=?";

        ps= conn.prepareStatement(sql);
        ps.setString(1, u.getName());
        ps.setString(2, u.getPassword());
        ps.setInt(3, u.getAge());
        ps.setString(4, u.getSex());
        ps.setInt(5, u.getsalary());
        ps.setInt(6,u.getId());

        int flag=ps.executeUpdate();
        if (flag>0){
            return true;
        }
        return false;
    }
}
