package com.fx.daolmpl;

import com.fx.dao.StockDao;
import com.fx.db.DBconnection;
import com.fx.vo.Stock;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StockDaolmpl implements StockDao {
    public Connection conn;
    public PreparedStatement ps;
    public ResultSet rs;

    @Override
    public boolean sadd(Stock u) {
        DBconnection db = new DBconnection();
        conn = db.getConn();

        String sql = "insert into stock values(s_id,?,?,?,?,?,?,?,?,?)";
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, u.getS_name());
            ps.setDouble(2, u.getSc_price());
            ps.setDouble(3, u.getT_price());
            ps.setDouble(4, u.getTh_price());
            ps.setDouble(5, u.getTl_price());
            ps.setInt(6,u.getVolume());
            ps.setInt(7,u.getTurnover());
            ps.setDouble(8,u.getPE());
            ps.setString(9, u.getCompany());


            int flag = ps.executeUpdate();
            if (flag > 0) {
                return true;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    @Override
    public ArrayList<Stock> selectallstock() {
        ArrayList<Stock> list = new ArrayList<Stock>();

        DBconnection db = new DBconnection();
        conn = db.getConn();

        String sql = "select * from stock";
        try {
            ps = conn.prepareStatement(sql);

            rs = ps.executeQuery();

            while (rs.next()) {
                    Stock u = new Stock();
                    u.setS_id(rs.getInt("s_id"));
                    u.setS_name(rs.getString("s_name"));
                    u.setSc_price(rs.getFloat("sc_price"));
                    u.setT_price(rs.getFloat("t_price"));
                    u.setTh_price(rs.getFloat("th_price"));
                    u.setTl_price(rs.getFloat("tl_price"));
                    u.setVolume(rs.getInt("volume"));
                    u.setTurnover(rs.getInt("turnover"));
                    u.setPE(rs.getDouble("PE"));
                    u.setCompany(rs.getString("company"));
                    list.add(u);
                }

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            return list;
        }

    @Override
    public boolean delete(int s_id) throws SQLException,ClassNotFoundException {
        DBconnection db = new DBconnection();
        conn = db.getConn();
        String sql="delete from stock where s_id = ?";

        ps= conn.prepareStatement(sql);
        ps.setInt(1,s_id);
        int flag=ps.executeUpdate();
        if (flag>0){
            return true;
        }
        return false;
    }

    @Override
    public boolean update(Stock s) throws SQLException, ClassNotFoundException {
        DBconnection db = new DBconnection();
        conn = db.getConn();

        String sql="update stock set s_name=?,sc_price=?,t_price=?,th_price=?,tl_price=?,volume=?,turnover=?,PE=?,company=? where s_id=?";

        ps= conn.prepareStatement(sql);
        ps.setString(1, s.getS_name());
        ps.setFloat(2,s.getSc_price());
        ps.setFloat(3,s.getT_price());
        ps.setFloat(4,s.getTh_price());
        ps.setFloat(5,s.getTl_price());
        ps.setInt(6,s.getVolume());
        ps.setInt(7,s.getTurnover());
        ps.setDouble(8,s.getPE());
        ps.setString(9,s.getCompany());
        ps.setInt(10,s.getS_id());

        int flag=ps.executeUpdate();
        if (flag>0){
            return true;
        }
        return false;
    }

    @Override
    public Stock selectbyid(int s_id) {
        DBconnection db = null;
        db = new DBconnection();
        conn = db.getConn();
        Stock u=new Stock();

        String sql="select * from stock where s_id= ?";
        try {
            ps= conn.prepareStatement(sql);
            ps.setInt(1,s_id);
            rs=ps.executeQuery();


            while (rs.next()){
                u.setS_id(rs.getInt("s_id"));
                u.setS_name(rs.getString("s_name"));
                u.setSc_price(rs.getFloat("sc_price"));
                u.setT_price(rs.getFloat("t_price"));
                u.setTh_price(rs.getFloat("th_price"));
                u.setTl_price(rs.getFloat("tl_price"));
                u.setVolume(rs.getInt("volume"));
                u.setTurnover(rs.getInt("turnover"));
                u.setPE(rs.getDouble("PE"));
                u.setCompany(rs.getString("company"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return u;
    }
}

