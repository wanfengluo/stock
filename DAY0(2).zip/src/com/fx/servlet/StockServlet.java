package com.fx.servlet;

import com.fx.dao.StockDao;
import com.fx.daolmpl.StockDaolmpl;
import com.fx.vo.Stock;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StockServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, UnsupportedEncodingException {

        request.setCharacterEncoding("utf-8");

        StockDao sd=new StockDaolmpl();
        ArrayList<Stock> list = sd.selectallstock();
        List<Stock> list2 = sd.selectallstock();

        Collections.shuffle(list2);
        List<Stock> randomStocks = list2.subList(0, Math.min(list2.size(), 7));

        request.setAttribute("randomStocks", randomStocks);

        request.setAttribute("stockinfo",list);

        request.getRequestDispatcher("stockManagement.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }

}
