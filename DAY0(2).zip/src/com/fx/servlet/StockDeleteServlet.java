package com.fx.servlet;

import com.fx.dao.StockDao;
import com.fx.daolmpl.StockDaolmpl;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class StockDeleteServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取请求参数中的id
        String idStr = request.getParameter("s_id");
        if (idStr == null || idStr.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "The 'id' parameter is required.");
            return;
        }

        try {
            int id = Integer.parseInt(idStr);
            StockDao StockDao = new StockDaolmpl();
            // 调用DAO层删除用户
            boolean isDeleted = StockDao.delete(id);

            // 根据删除操作结果创建JSON对象
            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("success", isDeleted);

            // 设置响应的Content-Type为application/json
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            // 将JSON对象写入响应
            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
        } catch (NumberFormatException e) {
            // 捕获参数转换异常
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "The 'id' parameter must be an integer.");
        } catch (SQLException e) {
            // 捕获数据库异常
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error occurred.");
        } catch (Exception e) {
            // 捕获其他异常
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred.");
        }
    }
}
