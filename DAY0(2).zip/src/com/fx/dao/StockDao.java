package com.fx.dao;

import com.fx.vo.Stock;

import java.sql.SQLException;
import java.util.ArrayList;

public interface StockDao {
    boolean sadd(Stock s);

    ArrayList<Stock> selectallstock();


     boolean delete(int s_id) throws SQLException,ClassNotFoundException;

    public boolean update(Stock s) throws SQLException, ClassNotFoundException;

    public Stock selectbyid(int s_id);
}
