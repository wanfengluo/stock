package servlet;

import dao.StockDao;
import daolmpl.StockDaolmpl;
import vo.Stock;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class StockServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        StockDao sd = new StockDaolmpl();
        List<Stock> list = sd.selectallstock();

        // 随机选择7个股票
        Collections.shuffle(list);
        List<Stock> randomStocks = list.subList(0, Math.min(list.size(), 7));

        request.setAttribute("stockinfo", list);
        request.setAttribute("randomStocks", randomStocks);

        request.getRequestDispatcher("StockManagement.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
