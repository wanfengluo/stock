package servlet;

import dao.UserDao;
import daolmpl.UserDaolmpl;
import vo.User;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

public class UserSelectByIdServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id=Integer.parseInt(req.getParameter("id"));

        UserDao ud=new UserDaolmpl();
        User u = ud.selectById(id);

        if (u!=null){
            req.setAttribute("userinfo",u);
            req.getRequestDispatcher("UserUpdate.jsp").forward(req,resp);

        }else{
            resp.sendRedirect("UserServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
