package servlet;

import dao.StockDao;
import daolmpl.StockDaolmpl;
import vo.Stock;
import dao.StockDao;
import daolmpl.StockDaolmpl;
import vo.Stock;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

public class StockSelectByidServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id=Integer.parseInt(req.getParameter("s_id"));

        StockDao ud=new StockDaolmpl();
        Stock u = ud.selectbyid(id);

        if (u!=null){
            req.setAttribute("stockinfo",u);
            req.getRequestDispatcher("StockUpdate.jsp").forward(req,resp);

        }else{
            resp.sendRedirect("StockServlet");
        }
    }
}
