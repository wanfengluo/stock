package servlet;

import dao.UserDao;
import daolmpl.UserDaolmpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String pwd = request.getParameter("pwd");

        HttpSession session = request.getSession();
        UserDao ud = new UserDaolmpl();
        try {
            boolean flag = ud.login(name, pwd);
            if (flag) {
                session.setAttribute("username", name);
                // 转发到MainServlet
                request.getRequestDispatcher("MainServlet").forward(request, response);
            } else {
                // 重定向到错误页面
                response.sendRedirect("error.jsp");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
