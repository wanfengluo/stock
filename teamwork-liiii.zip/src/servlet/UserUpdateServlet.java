package servlet;

import dao.UserDao;
import daolmpl.UserDaolmpl;
import vo.User;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

public class UserUpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id=Integer.parseInt(req.getParameter("id"));
        String name=req.getParameter("name");
        String pwd=req.getParameter("password");
        int age=Integer.parseInt(req.getParameter("age"));
        String sex=req.getParameter("sex");
        int salary=Integer.parseInt(req.getParameter("salary"));

        User u=new User(id,name,pwd,age,sex,salary);

        UserDao ud=new UserDaolmpl();
        try {
            boolean flag = ud.update(u);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        resp.sendRedirect("UserServlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
