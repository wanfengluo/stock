package servlet;

import dao.StockDao;
import daolmpl.StockDaolmpl;
import vo.Stock;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

public class StockUpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id=Integer.parseInt(req.getParameter("s_id"));
        String name=req.getParameter("s_name");
        Float scprice=Float.parseFloat(req.getParameter("sc_price"));
        Float tprice=Float.parseFloat(req.getParameter("t_price"));
        Float thprice=Float.parseFloat(req.getParameter("th_price"));
        Float tlprice=Float.parseFloat(req.getParameter("tl_price"));
        int volume=Integer.parseInt(req.getParameter("volume"));
        int turnover=Integer.parseInt(req.getParameter("turnover"));
        Double pe=Double.parseDouble(req.getParameter("PE"));
        String company=req.getParameter("company");

        Stock u=new Stock(id,name,scprice,tprice,thprice,tlprice,volume,turnover,pe,company);

        StockDao ud=new StockDaolmpl();
        try {
            boolean flag=ud.update(u);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        resp.sendRedirect("StockServlet");
    }
}
