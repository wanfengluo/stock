package vo;

public class Stock {
    private Integer s_id;
    private String s_name;
    private Float sc_price;
    private Float t_price;
    private Float th_price;
    private Float tl_price;
    private Integer volume;
    private Integer turnover;
    private Double PE;
    private String company;

    public Stock() {

    }


    public Integer getS_id() {
        return s_id;
    }

    public void setS_id(Integer s_id) {
        this.s_id = s_id;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }
    public Float getSc_price() {
        return sc_price;
    }

    public void setSc_price(Float sc_price) {
        this.sc_price = sc_price;
    }

    public Float getT_price(){
        return t_price;
    }
    public void setT_price(Float t_price){
        this.t_price=t_price;
    }
    public Float getTh_price(){return th_price;}

    public void setTh_price(Float th_price){
        this.th_price=th_price;
    }
    public Float getTl_price(){return tl_price;}

    public void setTl_price(Float tl_price){
        this.tl_price=tl_price;
    }

    public Integer getVolume(){return volume;}

    public void setVolume(Integer volume){
        this.volume=volume;
    }
    public Integer getTurnover(){return turnover;}

    public void setTurnover(Integer turnover){this.turnover=turnover;}

    public Double getPE(){return PE;};
    public void setPE(Double PE){this.PE=PE;}

    public String getCompany(){return company;}
    public void setCompany(String company){this.company=company;}
    @Override
    public String toString() {
        return "Stock{" +
                "id=" + s_id +
                ", name=" + s_name +
                ", sc_price=" + sc_price +
                ", t_price=" + t_price +
                ", th_price=" + th_price +
                ", tl_price=" + tl_price +
                ", volume=" + volume +
                ", turnover=" + turnover +
                ", PE=" + PE +
                ", company=" + company +
                '}';
    }

    public Stock(Integer s_id,String s_name,Float sc_price,Float t_price,Float th_price,Float tl_price,Integer volume,Integer turnover,Double PE,String company) {
        this.s_id = s_id;
        this.s_name = s_name;
        this.sc_price = sc_price;
        this.t_price=t_price;
        this.th_price = th_price;
        this.tl_price = tl_price;
        this.volume = volume;
        this.turnover = turnover;
        this.PE = PE;
        this.company = company;
    }

}
