package dao;

import vo.User;

import java.sql.SQLException;
import java.util.ArrayList;

public interface UserDao {
    //登录
    public boolean login(String name,String password) throws SQLException, ClassNotFoundException;

    public ArrayList<User>selectAll() throws SQLException, ClassNotFoundException;

    //增加
    public boolean add(User u) throws SQLException, ClassNotFoundException;

    //删除
    public boolean delete(int id) throws SQLException, ClassNotFoundException;

    public User selectById(int id);

    public boolean update(User u) throws SQLException, ClassNotFoundException;
}
